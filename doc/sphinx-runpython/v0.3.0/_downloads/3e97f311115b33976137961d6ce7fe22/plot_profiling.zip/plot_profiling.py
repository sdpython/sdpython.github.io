"""
Empty example
=============

This demonstrates one of the sphinx extension implemented here.

* use of epkg, link to :epkg:`sphinx-gallery`.

"""

import sphinx_runpython

print(sphinx_runpython.__version__)
